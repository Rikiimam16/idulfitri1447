import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// ============================================
// INISIALISASI SCENE
// ============================================
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0a1f2a);
scene.fog = new THREE.FogExp2(0x0a1f2a, 0.012);

const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(15, 6, 25);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.setPixelRatio(window.devicePixelRatio);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.autoRotate = true;
controls.autoRotateSpeed = 0.6;
controls.enableZoom = true;
controls.maxPolarAngle = Math.PI / 2.2;
controls.minDistance = 10;
controls.maxDistance = 40;
controls.target.set(0, 2, 0);

// ============================================
// PENCAHAYAAN
// ============================================
const ambientLight = new THREE.AmbientLight(0x404060);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xfff5e6, 2.0);
dirLight.position.set(8, 20, 10);
dirLight.castShadow = true;
dirLight.receiveShadow = true;
dirLight.shadow.mapSize.width = 2048;
dirLight.shadow.mapSize.height = 2048;
const d = 25;
dirLight.shadow.camera.left = -d;
dirLight.shadow.camera.right = d;
dirLight.shadow.camera.top = d;
dirLight.shadow.camera.bottom = -d;
dirLight.shadow.camera.near = 2;
dirLight.shadow.camera.far = 60;
scene.add(dirLight);

const pointLight1 = new THREE.PointLight(0xffaa33, 1.2, 35);
pointLight1.position.set(5, 7, 8);
scene.add(pointLight1);

const pointLight2 = new THREE.PointLight(0x44aaff, 0.8, 35);
pointLight2.position.set(-6, 5, -8);
scene.add(pointLight2);

const pointLight3 = new THREE.PointLight(0xff8844, 1.0, 30);
pointLight3.position.set(3, 9, -7);
scene.add(pointLight3);

const backLight = new THREE.PointLight(0x446688, 1.0, 35);
backLight.position.set(-6, 5, -18);
scene.add(backLight);

// ============================================
// LANTAI DENGAN POLA
// ============================================
const floorGeometry = new THREE.CircleGeometry(50, 64);
const floorMaterial = new THREE.MeshStandardMaterial({ 
    color: 0x1a4a3a, 
    emissive: 0x0a2a1a,
    transparent: true, 
    opacity: 0.25,
    side: THREE.DoubleSide
});
const floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -3.0;
floor.receiveShadow = true;
scene.add(floor);

// Lingkaran dekoratif di lantai
const ringGeometry = new THREE.TorusGeometry(15, 0.2, 16, 100);
const ringMaterial = new THREE.MeshStandardMaterial({ color: 0xffaa33, emissive: 0x442200, transparent: true, opacity: 0.3 });
const ring = new THREE.Mesh(ringGeometry, ringMaterial);
ring.rotation.x = Math.PI / 2;
ring.position.y = -2.8;
scene.add(ring);

const ring2 = new THREE.TorusGeometry(10, 0.15, 16, 100);
const ring2Material = new THREE.MeshStandardMaterial({ color: 0x44aaff, emissive: 0x112244, transparent: true, opacity: 0.2 });
const ring2Obj = new THREE.Mesh(ring2, ring2Material);
ring2Obj.rotation.x = Math.PI / 2;
ring2Obj.position.y = -2.8;
scene.add(ring2Obj);

// ============================================
// BINTANG LATAR
// ============================================
const starsGeometry = new THREE.BufferGeometry();
const starsCount = 4000;
const starsPositions = new Float32Array(starsCount * 3);

for (let i = 0; i < starsCount * 3; i += 3) {
    const r = 100 + Math.random() * 100;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    
    starsPositions[i] = r * Math.sin(phi) * Math.cos(theta);
    starsPositions[i+1] = r * Math.sin(phi) * Math.sin(theta);
    starsPositions[i+2] = r * Math.cos(phi);
}

starsGeometry.setAttribute('position', new THREE.BufferAttribute(starsPositions, 3));

const starsMaterial = new THREE.PointsMaterial({ 
    color: 0xffffff, 
    size: 0.2, 
    transparent: true, 
    opacity: 0.9,
    blending: THREE.AdditiveBlending
});

const stars = new THREE.Points(starsGeometry, starsMaterial);
scene.add(stars);

// ============================================
// BINTANG JATUH
// ============================================
const shootingStars = [];

function createShootingStar() {
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(2 * 3);
    const startX = (Math.random() - 0.5) * 80;
    const startY = 30 + Math.random() * 20;
    const startZ = (Math.random() - 0.5) * 80;
    const endX = startX + (Math.random() - 0.5) * 40;
    const endY = startY - 30 - Math.random() * 20;
    const endZ = startZ + (Math.random() - 0.5) * 40;
    
    positions[0] = startX; positions[1] = startY; positions[2] = startZ;
    positions[3] = endX; positions[4] = endY; positions[5] = endZ;
    
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    
    const material = new THREE.LineBasicMaterial({ 
        color: new THREE.Color().setHSL(Math.random() * 0.2 + 0.1, 1, 0.6),
        transparent: true,
        opacity: 1
    });
    
    const star = new THREE.Line(geometry, material);
    star.userData = {
        life: 1.0,
        speed: 0.005 + Math.random() * 0.01
    };
    
    return star;
}

for (let i = 0; i < 5; i++) {
    const star = createShootingStar();
    shootingStars.push(star);
    scene.add(star);
}

// ============================================
// PARTIKEL GEMERLAP
// ============================================
const sparkleGeometry = new THREE.BufferGeometry();
const sparkleCount = 800;
const sparklePositions = new Float32Array(sparkleCount * 3);
const sparkleColors = new Float32Array(sparkleCount * 3);

for (let i = 0; i < sparkleCount; i++) {
    sparklePositions[i*3] = (Math.random() - 0.5) * 60;
    sparklePositions[i*3+1] = (Math.random() - 0.5) * 30;
    sparklePositions[i*3+2] = (Math.random() - 0.5) * 60;
    
    const colorRand = Math.random();
    if (colorRand < 0.6) {
        sparkleColors[i*3] = 1.0; sparkleColors[i*3+1] = 0.9; sparkleColors[i*3+2] = 0.5;
    } else if (colorRand < 0.8) {
        sparkleColors[i*3] = 0.8; sparkleColors[i*3+1] = 0.9; sparkleColors[i*3+2] = 1.0;
    } else {
        sparkleColors[i*3] = 1.0; sparkleColors[i*3+1] = 0.8; sparkleColors[i*3+2] = 0.9;
    }
}

sparkleGeometry.setAttribute('position', new THREE.BufferAttribute(sparklePositions, 3));
sparkleGeometry.setAttribute('color', new THREE.BufferAttribute(sparkleColors, 3));

function createSparkleTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
    gradient.addColorStop(0, 'rgba(255,255,255,1)');
    gradient.addColorStop(0.5, 'rgba(255,255,0,0.5)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 32, 32);
    
    return new THREE.CanvasTexture(canvas);
}

const sparkleMaterial = new THREE.PointsMaterial({
    size: 0.3,
    map: createSparkleTexture(),
    vertexColors: true,
    blending: THREE.AdditiveBlending,
    transparent: true,
    depthWrite: false
});

const sparkles = new THREE.Points(sparkleGeometry, sparkleMaterial);
scene.add(sparkles);

// ============================================
// AWAN
// ============================================
function createCloud(x, y, z, scale) {
    const group = new THREE.Group();
    
    const cloudMaterial = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: 0x224466,
        transparent: true,
        opacity: 0.4,
        side: THREE.DoubleSide
    });
    
    const spheres = [
        { pos: [0, 0, 0], scale: 1.0 },
        { pos: [1.2, 0.2, 0.3], scale: 0.8 },
        { pos: [-1.1, -0.1, 0.4], scale: 0.7 },
        { pos: [0.5, 0.5, -0.5], scale: 0.6 },
        { pos: [-0.3, -0.3, 0.8], scale: 0.5 },
        { pos: [0.8, -0.2, -0.7], scale: 0.5 }
    ];
    
    spheres.forEach(s => {
        const geo = new THREE.SphereGeometry(1.5 * s.scale, 7, 7);
        const mesh = new THREE.Mesh(geo, cloudMaterial);
        mesh.position.set(s.pos[0], s.pos[1], s.pos[2]);
        mesh.castShadow = false;
        mesh.receiveShadow = false;
        group.add(mesh);
    });
    
    group.position.set(x, y, z);
    group.scale.set(scale, scale * 0.5, scale);
    
    return group;
}

const cloud1 = createCloud(-15, 12, -10, 4);
scene.add(cloud1);
const cloud2 = createCloud(12, 15, -5, 5);
scene.add(cloud2);
const cloud3 = createCloud(5, 18, 15, 3.5);
scene.add(cloud3);
const cloud4 = createCloud(-8, 20, 12, 4.5);
scene.add(cloud4);

// ============================================
// LOADING SELESAI
// ============================================
setTimeout(() => {
    document.getElementById('loadingScreen').classList.add('hidden');
    document.getElementById('loadingStatus').innerText = 'Selesai!';
}, 1500);

// ============================================
// ANIMASI
// ============================================
let clock = new THREE.Clock();

function animate() {
    requestAnimationFrame(animate);
    
    const delta = clock.getDelta();
    const elapsedTime = performance.now() * 0.001;
    
    // Rotasi bintang latar
    stars.rotation.y += 0.0001;
    
    // Animasi bintang jatuh
    shootingStars.forEach((star, index) => {
        star.userData.life -= star.userData.speed;
        star.material.opacity = star.userData.life;
        
        if (star.userData.life <= 0) {
            scene.remove(star);
            shootingStars.splice(index, 1);
            
            const newStar = createShootingStar();
            shootingStars.push(newStar);
            scene.add(newStar);
        }
    });
    
    // Tambah bintang jatuh baru jika kurang
    if (shootingStars.length < 8 && Math.random() < 0.01) {
        const newStar = createShootingStar();
        shootingStars.push(newStar);
        scene.add(newStar);
    }
    
    // Animasi awan
    cloud1.position.x += 0.002;
    cloud2.position.x -= 0.003;
    cloud3.position.z += 0.002;
    cloud4.position.z -= 0.001;
    
    if (cloud1.position.x > 20) cloud1.position.x = -20;
    if (cloud2.position.x < -20) cloud2.position.x = 20;
    if (cloud3.position.z > 20) cloud3.position.z = -20;
    if (cloud4.position.z < -20) cloud4.position.z = 20;
    
    // Animasi sparkles
    sparkles.material.opacity = 0.5 + Math.sin(elapsedTime * 2) * 0.3;
    
    controls.update();
    renderer.render(scene, camera);
}

animate();

// ============================================
// HANDLE RESIZE
// ============================================
window.addEventListener('resize', onWindowResize, false);

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}